using Common;
using NUnit.Framework;
using System.Linq;
using Windsor.Test;

namespace Tests
{
    public class Tests
    {
        [OneTimeSetUp]
        public void Setup()
        {
        }

        [Test]
        public void ContactStaff_GetPeople()
        {

            var handler = Registry.container.Resolve<ContactStaffHandler>();
            var list = handler.HandlerGetPeople();
            Assert.AreEqual(list.Count(), 5);
        }
        [Test]
        public void ContactStaff_GetPerson()
        {

            var handler = Registry.container.Resolve<ContactStaffHandler>();
            var person = handler.HandlerGetPerson();
            Assert.AreEqual(person, "Maggie");
        }

        [Test]
        public void ContactStaff_GetPeople_Interface()
        {

            var root = Registry.container.Resolve<IRepository>();
            var list = root.GetPeople();
            Assert.AreEqual(list.Count(), 5);
        }
        [Test]
        public void ContactStaff_GetPerson_Interface()
        {

            var root = Registry.container.Resolve<IRepository>();
            var person = root.GetById(2);
            Assert.AreEqual(person, "Maggie");
        }

    }
}