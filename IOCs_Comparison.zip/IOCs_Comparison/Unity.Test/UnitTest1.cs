using NUnit.Framework;
using Microsoft.Practices.Unity;
using Unity.Test;
using Unity;
using System.Linq;

namespace Tests
{
    public class Tests
    {
        IUnityContainer container;
        [OneTimeSetUp]
        public void Setup()
        {
            container = Registry.container;
        }

        [Test]
        public void ContactStaff_GetPeople()
        {
             
            var handler = container.Resolve<ContactStaffHandler>();
            var list = handler.HandlerGetPeople();
            Assert.AreEqual(list.Count(), 5);
        }
        [Test]
        public void ContactStaff_GetPerson()
        {
            var handler = container.Resolve<ContactStaffHandler>();
            var person = handler.HandlerGetPerson();
            Assert.AreEqual(person, "Maggie");
        }
    }
}