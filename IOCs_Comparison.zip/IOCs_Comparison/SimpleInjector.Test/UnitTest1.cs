using NUnit.Framework;
using SimpleInjector.Test;
using System.Linq;

namespace Tests
{
    public class Tests
    {

        [SetUp]
        public void Setup()
        { 
        }

        [Test]
        public void ContactStaff_GetPeople()
        {
            var handler = Registry.container.GetInstance<ContactStaffHandler>();
            var list = handler.HandlerGetPeople();
            Assert.AreEqual(list.Count(), 5);
        }
        [Test]
        public void ContactStaff_GetPerson()
        {
            var handler = Registry.container.GetInstance<ContactStaffHandler>();
            var person = handler.HandlerGetPerson();
            Assert.AreEqual(person,"Maggie");
        }
    }
}